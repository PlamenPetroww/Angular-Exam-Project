/* export const environment = {
    appUrl: 'https://test-angular-e21b5-default-rtdb.europe-west1.firebasedatabase.app'
};
 */

export const environment = {
    firebase: {
    apiKey: 'AIzaSyA2RRkNCa07yGKqZxPBcobgxvotqLr4KFk',
    authDomain: 'test-angular-e21b5.firebaseapp.com',
    databaseURL:
      'https://test-angular-e21b5-default-rtdb.europe-west1.firebasedatabase.app',
    projectId: 'test-angular-e21b5',
    storageBucket: 'test-angular-e21b5.appspot.com',
    messagingSenderId: '577584796191',
    appId: '1:577584796191:web:751a492f030f4b177cfb2a',
  },
  production: true,
  appUrl:
    'https://test-angular-e21b5-default-rtdb.europe-west1.firebasedatabase.app/',
};
