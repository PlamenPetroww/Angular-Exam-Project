export interface Lesson {
    title: string;
    price: string;
    duration: string;
    img: string;
    description: string;
    subscribers: number;
    userEmail: string;
    offerId: string;
}