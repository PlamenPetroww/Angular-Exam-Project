export interface Offer {
    author?: string;
    title: string;
    img: string;
    description: string;
    duration: number;
    price: number;
}